#!/usr/bin/env bash
# Meshes and runs the OpenFOAM case in this folder. Source the OpenFOAM environment first, for example:
#   source /usr/lib/openfoam/openfoam2412/etc/bashrc
set -eo pipefail
cd "$(dirname "$0")"
NP="${NP:-1}"
blockMesh 2>&1 | tee log.blockMesh
snappyHexMesh -overwrite 2>&1 | tee log.snappyHexMesh
checkMesh 2>&1 | tee log.checkMesh || true
if [ "$NP" -gt 1 ]; then
  sed -i "s/^numberOfSubdomains.*/numberOfSubdomains $NP;/" system/decomposeParDict
  decomposePar -force 2>&1 | tee log.decomposePar
  OVER=""; mpirun --oversubscribe -np 1 true >/dev/null 2>&1 && OVER="--oversubscribe"   # Open MPI only
  mpirun $OVER -np "$NP" simpleFoam -parallel 2>&1 | tee log.simpleFoam
  reconstructPar -latestTime 2>&1 | tee log.reconstructPar
else
  simpleFoam 2>&1 | tee log.simpleFoam
fi
