Fixed-wing UAV — OpenFOAM: Steady incompressible RANS (simpleFoam)
==================================================================

Prepared by the AeroSuite 26 high-fidelity bridge. Everything needed to run is in this folder.

Run it
------
  source /usr/lib/openfoam/openfoam2412/etc/bashrc
  bash run.sh

Then bring these files back to the bridge page (drop them, or the whole folder zipped):
  postProcessing/forceCoeffs1/0/coefficient.dat
  postProcessing/forces1/0/force.dat
  postProcessing/solverInfo1/0/solverInfo.dat
  log.simpleFoam
  log.snappyHexMesh
  log.checkMesh

What is in the deck
-------------------
- Surface: full-span wing lofted from the case planform (NACA 4412, taper, quarter-chord sweep, dihedral and twist), closed at the tips.
- Mesh: background block of 50 × 87 × 40 cells, cubic (0.0681 m) around the body and stretched towards the far boundaries; snappyHexMesh refines 1 times to 0.0340 m on the surface. Wall functions (Spalding) carry the boundary layer.
- Force coefficients use reference area 1.1 m² and length 0.34028 m; lift and drag are resolved along and across the freestream at 3°.
- Extra: geometry/aircraft.geo is a parametric Gmsh script of the wing (and fuselage) in a far-field box, for meshing the 3-D shape at any resolution.

Case hash (SHA-256): fdca7564b847fb8111147717d0735675f670f635ed9da625513602a2c0f049f0
